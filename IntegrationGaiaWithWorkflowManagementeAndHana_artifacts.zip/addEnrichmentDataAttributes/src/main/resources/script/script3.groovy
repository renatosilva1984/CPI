import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    String sku = message.getProperty("reference")
    assert sku
    
    message.setHeader("sku", sku)
    
    return message;
}