import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.*
import java.util.HashMap;

def Map parseJson(String json){
    JsonSlurper slurper = new JsonSlurper()
    Map map = slurper.parseText(json)

    return map
}

def getBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def mBody = parseJson(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def Message processData(Message message) {
    Map result = getBodyAsMap(message)
        String referenceSku = message.getProperty("sku")
        assert referenceSku
    
        Map body = result.data[0]
        assert body.sku == referenceSku
    
        String jsonBody = toJSON(body)
        message.setBody(jsonBody) 

    return message;
}