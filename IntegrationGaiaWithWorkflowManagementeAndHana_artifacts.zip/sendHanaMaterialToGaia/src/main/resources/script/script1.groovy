import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    String sku = message.getHeader("sku", String)
    
    if (!sku) throw new Exception("Missing sku header")
    
    message.setProperty("sku", sku)
    
    return message;
}