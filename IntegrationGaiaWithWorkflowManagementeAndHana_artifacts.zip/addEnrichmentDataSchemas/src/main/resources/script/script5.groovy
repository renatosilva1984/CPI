import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def getBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def jsonSlurper = new JsonSlurper()
    def mBody = jsonSlurper.parseText(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}


def Message processData(Message message) {
    Map body = getBodyAsMap(message)
    ArrayList<Map> attributes = body.attributes
    Closure isHierarchyAttribute = { attr -> attr.type == 'hierarchy'}
    ArrayList<Map> hierarchies = attributes.findAll(isHierarchyAttribute)
    String pph = message.getProperty("hierarchy")
    ArrayList<Map> schemas = hierarchies.collect{ hierarchy -> 
        Map schema = [
            id: hierarchy._id,
            id_hierarchy: pph,
            name: hierarchy.name,
            format: hierarchy.format,
            multi_select: hierarchy.multiSelect,
            area: hierarchy.area,
            required: hierarchy.required,
            brand: hierarchy.brandMetadata.brand,
            source_hierarchy: hierarchy.brandMetadata.hierarchyId
        ]
        return schema
    }

    String sku = message.getProperty("sku")
    ArrayList<Map> entries = schemas.collect{ schema -> 
        Map entry = [
            schema: schema,
            data: [
                field_schema_id: schema.id,
                material_sku: sku
            ]
        ]
        return entry
    }

    Map newBody = [
        "payload": entries
    ]

    String jsonBody = toJSON(newBody)

    message.setBody(jsonBody)

    Map nonHierarchyAttributes = [
        attributes: attributes.findAll{!isHierarchyAttribute(it)}
    ]
    String jsonNonHierarchyAttributes = toJSON(nonHierarchyAttributes, false)
    message.setProperty("nonHierarchyAttributes", jsonNonHierarchyAttributes)

    return message
}