import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def getBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def jsonSlurper = new JsonSlurper()
    def mBody = jsonSlurper.parseText(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def String toJSON(ArrayList inp, Boolean pretty = true) {
    String json = JsonOutput.toJson(inp)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def Void setProcessDirectProperties(Message message, Map gaiaMaterial) {
    String sku = gaiaMaterial.sku
    assert sku

    Map hierarchyMap = gaiaMaterial.hierarchies
    ArrayList<String> primaryHierarchy = hierarchyMap.primary
    String hierarchy = primaryHierarchy.join("/")
    assert hierarchy

    Map properties = [
        "sku": sku,
        "hierarchy": hierarchy
    ]
    message.setProperties(properties)
}

def String parseAsHanaMaterial(Map gaiaMaterial) {
    String sku = gaiaMaterial.sku
    String name = gaiaMaterial.name
    String brand = gaiaMaterial.brand
    String subBrand = gaiaMaterial.subBrand
    String group = gaiaMaterial.group
    
    Map gaiaHierarchies = gaiaMaterial.hierarchies
    String pph = gaiaHierarchies.primary.join("/")
    
    

    Map hanaMaterial = [
        sku: sku,
        name: name,
        brand: brand,
        sub_brand: subBrand,
        group: group,
        pph: pph
    ]

    String hanaMaterialJson = toJSON(hanaMaterial)

    return hanaMaterialJson
}

def Message processData(Message message) {
    Map gaiaMaterial = getBodyAsMap(message)

    String material = parseAsHanaMaterial(gaiaMaterial)
    message.setBody(material)

    setProcessDirectProperties(message, gaiaMaterial)

    return message;
}