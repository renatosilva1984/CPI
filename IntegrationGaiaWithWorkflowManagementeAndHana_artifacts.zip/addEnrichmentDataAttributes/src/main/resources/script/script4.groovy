import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Map parseJson(String json){
    JsonSlurper slurper = new JsonSlurper()
    Map map = slurper.parseText(json)

    return map
}

def getBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def mBody = parseJson(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def Message processData(Message message) {
    String targetSku = message.getProperty("targetSku")
    Map referenceMaterial = getBodyAsMap(message)
    ArrayList referenceAttributes = referenceMaterial.attributes
    Closure parseAttributeValue = { Map attribute -> 
        ArrayList values = attribute.values
        Map firstValue = values[0]
        String firstValueId = firstValue?.valueId
        Boolean isLov = firstValueId != null && firstValueId != ""

        switch(true) {
            case (values.size() > 1 && isLov):                

                ArrayList idsArray = values.collect{ it.valueId }
                String ids = idsArray.join(",")
                return ids
                break
             case (values.size() > 1 && !isLov):                

                ArrayList valuesArray = values.collect{ it.value }
                String value = valuesArray.join(" ")
                return value
                break

            case (values.size() == 1 && isLov):
                return firstValueId
            break

            case (values.size() == 1 && !isLov):
                return firstValue.value
            break

            default:
                throw new Exception("Received empty valued attribute.")
            break
        }
    }

    ArrayList hanaValues = referenceAttributes.collect({Map attr -> 
        String schemaId = attr.id
        String value = parseAttributeValue(attr)

        Map hanaValue = [
            "id": schemaId,
            "value": value
        ]

        return hanaValue
    })
    
    Map hanaBody = [
        "sku": targetSku,
        "attributes": hanaValues
    ]
    String hanaJson = toJSON(hanaBody)

    message.setBody(hanaJson)
    
    return message;
}