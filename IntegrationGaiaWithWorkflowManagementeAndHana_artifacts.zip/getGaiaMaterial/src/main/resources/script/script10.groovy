import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    def ex = message.getProperty("CamelExceptionCaught");
    if (ex!=null) {
        
        message.setHeader('h_message_error', ex.getMessage());
        
    }
    return message;
}