import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
    
    def Message processData(Message message) {
        def builder = new JsonBuilder()
        def date = new Date()
        createdDate = date.format("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("GMT-3"));

        def log = builder{
            "hierarchy_id" message.getProperties().get("hierarchy_id")
            "description" message.getBody(String)
            "code" 500
            "artifact" "updateHanaSchemas"
            "task" this.class.getSimpleName()
            "created_at" createdDate
            "updated_at" createdDate
        }
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(log)))
        return message;
        }
    