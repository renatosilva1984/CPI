/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
    
    def retMod = message.getProperty("DataModifyReturnType");
    def retAdd = message.getProperty("DataAddReturnType");
    def xmlOut = new XmlParser().parseText("<root/>");
    
    def nodeResult = new Node(null, 'Result');
    def nodeSapRetMod = new Node(null, 'SapReturn');
    def nodeSapRetAdd = new Node(null, 'SapReturn');

    new Node(nodeResult, 'code', '200'); 
    new Node(nodeResult, 'message', 'Success');

    //Monta retorno referente à chamada da BAPI_ALM_NOTIF_DATA_MODIFY 
    if (message.getProperty("callDataModify") == "X") {
        if (retMod != 'E') {
            new Node(nodeSapRetMod, 'classeDeMensagem', 'ZPM');
            new Node(nodeSapRetMod, 'ctgMensSSucessoEErroWAvisoIInformACancel', 'S');
            new Node(nodeSapRetMod, 'linhaEmParametro', '0');
            new Node(nodeSapRetMod, 'logDeAplicacaoNu0SequencialInternoDaMensagem', '000000');
            new Node(nodeSapRetMod, 'nu0Mensagem', '006');
            new Node(nodeSapRetMod, 'textoDeMensagem', 'Nota PM ' + message.getProperty("nrNota") + ' alterada com sucesso!');
            new Node(null, nodeSapRetMod);
        } else {
            new Node(nodeSapRetMod, 'classeDeMensagem', message.getProperty("DataModifyReturnID"));
            new Node(nodeSapRetMod, 'ctgMensSSucessoEErroWAvisoIInformACancel', message.getProperty("DataModifyReturnType"));
            new Node(nodeSapRetMod, 'linhaEmParametro', message.getProperty("DataModifyReturnRow"));
            new Node(nodeSapRetMod, 'logDeAplicacaoNu0SequencialInternoDaMensagem', message.getProperty("DataModifyReturnLogMsgNo"));
            new Node(nodeSapRetMod, 'nu0Mensagem',  message.getProperty("DataModifyReturnNumber"));
            new Node(nodeSapRetMod, 'sistemaSistemaLogicoDoQualProvemAMensagem',  message.getProperty("DataModifyReturnSystem"));
            new Node(nodeSapRetMod, 'textoDeMensagem',  message.getProperty("DataModifyReturnMessage"));
            new Node(nodeSapRetMod, 'variavelMensagens',  message.getProperty("DataModifyReturnMessageV1"));
            new Node(nodeSapRetMod, 'variavelMensagens32',  message.getProperty("DataModifyReturnMessageV2"));
            new Node(null, nodeSapRetMod);
        }
    }

    //Monta retorno referente à chamada da BAPI_ALM_NOTIF_DATA_ADD
    if (message.getProperty("callDataAdd") == "X") {
        if (retAdd != 'E') {
            new Node(nodeSapRetAdd, 'classeDeMensagem', 'ZPM');
            new Node(nodeSapRetAdd, 'ctgMensSSucessoEErroWAvisoIInformACancel', 'S');
            new Node(nodeSapRetAdd, 'linhaEmParametro', '0');
            new Node(nodeSapRetAdd, 'logDeAplicacaoNu0SequencialInternoDaMensagem', '000000');
            new Node(nodeSapRetAdd, 'nu0Mensagem', '006');
            new Node(nodeSapRetAdd, 'textoDeMensagem', 'Inclusão de defeito, causa e ação ' + message.getProperty("nrNota") + ' finalizada com sucesso!');
            new Node(null, nodeSapRetAdd);
    
        } else {
            new Node(nodeSapRetAdd, 'classeDeMensagem',  message.getProperty("DataAddReturnID"));
            new Node(nodeSapRetAdd, 'ctgMensSSucessoEErroWAvisoIInformACancel', message.getProperty("DataAddReturnType"));
            new Node(nodeSapRetAdd, 'linhaEmParametro', message.getProperty("DataAddReturnRow"));
            new Node(nodeSapRetAdd, 'logDeAplicacaoNu0SequencialInternoDaMensagem', message.getProperty("DataAddReturnLogMsgNo"));
            new Node(nodeSapRetAdd, 'nu0Mensagem', message.getProperty("DataAddReturnNumber"));
            new Node(nodeSapRetAdd, 'sistemaSistemaLogicoDoQualProvemAMensagem', message.getProperty("DataAddReturnSystem"));       
            new Node(nodeSapRetAdd, 'textoDeMensagem',  message.getProperty("DataAddReturnMessage"));
            new Node(nodeSapRetAdd, 'variavelMensagens',  message.getProperty("DataAddReturnMessageV1"));
            new Node(nodeSapRetAdd, 'variavelMensagens32',  message.getProperty("DataAddReturnMessageV2"));
            new Node(null, nodeSapRetAdd);
        }
    }
    
    xmlOut.append(nodeResult);
    
    if (message.getProperty("callDataModify") == "X") {
        xmlOut.append(nodeSapRetMod);
    }
    if (message.getProperty("callDataAdd") == "X") {
        xmlOut.append(nodeSapRetAdd);
    }

    message.setBody(groovy.xml.XmlUtil.serialize(xmlOut));
    
    return message;
}