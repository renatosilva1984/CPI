import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    Map properties = message.getProperties()

    String targetSku = properties.targetSku
    String sourceSku = properties.sourceSku

    assert sourceSku
    assert targetSku

    return message
}