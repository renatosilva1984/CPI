import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
    
    def Message processData(Message message) {
        def builder = new JsonBuilder()
        def date = new Date()
        createdDate = date.format("yyyy-MM-dd HH:mm:ss", TimeZone.getTimeZone("GMT-3"));

        def hierarchy = message.getProperties().get("hierarchy") 
        def error = message.getBody(String)

        def log = builder{
            "sku" "000UHS"
            "description" "erro na hora de atualizar os schemas para hierarquia $hierarchy, $error;"
            "code" message.getHeaders().get("CamelHttpResponseCode")
            "artifact" "updateHanaSchemas"
            "created_at" createdDate
        }
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(log)))
        return message;
    }