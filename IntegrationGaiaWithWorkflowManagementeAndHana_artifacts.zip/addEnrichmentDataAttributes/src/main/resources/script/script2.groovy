import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def toPrettyJson(input) {
    def json = JsonOutput.toJson(input)
    return JsonOutput.prettyPrint(json)
}

def isString(input) {
    return input instanceof String
}

def Message processData(Message message) {
    
    def map = message.getHeaders()
    def sku = map.get('sku')
    
    def body = message.getBody(String)
    def jsonParser = new JsonSlurper()
    def jsonObject = jsonParser.parseText(body)

    def referenceMaterial = jsonObject.data[0]
    def referenceAttributes = referenceMaterial.attributes

    def hanaAttributes = referenceAttributes.collect{ attr ->
        attr.values = attr.values.collect{ value ->
            return value.collectEntries{ [it.key, it.value.toString()] }
        }
        return attr
    }

    def mapHana = [
        sku: sku,
        attributes: hanaAttributes
    ]

    message.setBody(toPrettyJson(mapHana))
    
    return message;
}