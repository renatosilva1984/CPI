import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
    
    def Message processData(Message message) {
        def body = message.getBody(String)
        def jsonParser = new JsonSlurper()
        def jsonObj = jsonParser.parseText(body)
        
        def builder = new JsonBuilder();
        def newJsonObj = builder{
            "payload" jsonObj
        }
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(newJsonObj)))
        return message
        }