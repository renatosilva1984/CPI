import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def getBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def jsonSlurper = new JsonSlurper()
    def mBody = jsonSlurper.parseText(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def Map modifyMap(Map input, Map toRename = [:], ArrayList toKeep = []) {
    Map output = [:]
    
    for (entry in input) {
        String k = entry.key
        def v = entry.value
        if(toRename.containsKey(k)) {
            String newKey = toRename[k]
            output[newKey] = v
        }
        
        if(toKeep.contains(k)) {
            output[k] = v
        }
    }

    return output
}

def Map getSchema(Map input) {
    Closure getData = { Map dataInput -> 
        // get data
        Map dataRename = [
            "_id": "id"
        ]
        ArrayList dataKeep = [
            "name",
            "type",
            "uom",
            "format",
            "multiSelect",
            "maxSize",
            "min",
            "max",
            "area",
            "required"
        ]
        Map data = modifyMap(dataInput, dataRename, dataKeep)

        return data
    }

    Closure getValueHep = {Map vhInput ->
        ArrayList<Map> oldValueHelp = vhInput.valueHelp

        ArrayList<Map> valueHelp = oldValueHelp.collect{ Map entry ->
            Map entryRename = [
                valueId: "id",
                subValue: "sub_value"
            ]
            ArrayList<String> entryKeep = [
                "value"
            ]
            Map newEntry = modifyMap(entry, entryRename, entryKeep)
            return newEntry
        }

        return valueHelp
    }

    Map schema = [:]
    schema.data = getData(input)

    if (input.format == "LOV") {
        schema.valueHelp = getValueHep(input)
    }

    return schema
}

def Message processData(Message message) {
    Map body = getBodyAsMap(message)
    String sku = message.getProperty("sku")
    String id_hierarchy = message.getProperty("hierarchy")
    ArrayList<Map> attributes = body.attributes
    ArrayList schemas = attributes.collect{ Map attribute ->
        Map schema = getSchema(attribute)
        schema.data.id_hierarchy = id_hierarchy

        assert schema.data.id
        assert schema.data.id_hierarchy

        Map data = [
            "field_schema_id": schema.data.id,
            "material_sku": sku
        ]

        Map entry = [
            "schema": schema,
            "data": data,
        ]

        return entry
    }

    Map newBody = [
        "payload": schemas
    ]

    String jsonBody = toJSON(newBody)

    message.setBody(jsonBody)

    return message
}