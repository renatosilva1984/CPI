import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    //Body 
       def body = message.getBody(java.lang.String)as String;
       def messageHeaders = message.getHeaders();
       
       String exceptionBody = "Erro de validação ou conexão com SAP MDG";
    
       throw new Exception(exceptionBody);

       return message;
}