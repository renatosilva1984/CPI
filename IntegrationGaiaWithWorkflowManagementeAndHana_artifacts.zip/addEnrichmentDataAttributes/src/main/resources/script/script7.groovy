import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Map parseJson(String json){
    JsonSlurper slurper = new JsonSlurper()
    Map map = slurper.parseText(json)

    return map
}

def getBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def mBody = parseJson(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def Message processData(Message message) {
    String targetSku = message.getProperty("targetSku")
    Map material = getBodyAsMap(message)
    ArrayList referenceAttributes = material.attributes
    ArrayList nonEmptyReferenceAttributes = referenceAttributes.findAll{
        return it.values.size() && it.values[0] != ''
    }
    material.attributes = nonEmptyReferenceAttributes

    String filteredMaterial = toJSON(material, true)

    message.setBody(filteredMaterial)
    
    return message;
}