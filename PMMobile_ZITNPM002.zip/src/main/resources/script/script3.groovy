/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */

import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;

def Message processData(Message message) {
    
    def body = message.getBody(String)
    def xml = new XmlParser().parseText(body);


    //*** Indica chamada das BAPIs pelo preenchimento os campos obrigatórios ***
    def callDataModify = new String("");
    def callDataAdd = new String("");
    
    def it = xml.notifHeader.iterator();
    while (it.hasNext()) {
        def next = it.next();
        if (next.inicioDaAvariaData.text() != '' || next.fimDaAvariaData.text() != '' || next.equipamento.text() != '' || next.textoBreve.text() != '' 
            || next.centroDeTrabalho.text() != '' || next.centroDePlanejamentoDeManutencao.text() != '' || next.grupoDePlanejamentoParaServicosClienteEManutencao.text() != '') {
            callDataModify = "X";
        }
        break;
    }
    message.setProperty("callDataModify", callDataModify);


    it = xml.notifAddItem.iterator();
    while (it.hasNext()) {
        def next = it.next();
        if (next.nuItemNoRegistroDoItem.text() != '' || next.chaveDeObjeto.text() != '' || next.nuOrdenacaoParaOItem.text() != '' 
            || next.textoBreveReferenteAoItemDaNota.text() != '' || next.grupoDeCodigosProblemas.text() != '' || next.codigoDoProblemaOuDoDano.text() != ''
            || next.grupoDeCodesPartesDeObjetos.text() != '' || next.parteDoObjeto.text() != '' || next.conjunto.text() != '') {
            callDataAdd = "X";
        }
        break;
    }
    if (callDataAdd == "") {
        it = xml.notifAddCaus.iterator();
        while (it.hasNext()) {
            def next = it.next();
            if (next.nuOrdenacaoParaACausa.text() != '' || next.nuItemNoRegistroDoItem.text() != '' || next.textoReferenteaCausa.text() != '' 
                || next.grupoDeCodesCausa.text() != '' || next.codigoDaCausa.text() != '' || next.nuOrdenacaoParaOItem.text() != '') {
                callDataAdd = "X";
            }
            break;
        }
    }
    if (callDataAdd == "") {
        it = xml.notifAddActv.iterator();
        while (it.hasNext()) {
            def next = it.next();
            if (next.nuOrdenacaoParaAcao.text() != '' || next.textoDaAtividade.text() != '' || next.grupoDeCodesAtividades.text() != '' 
                || next.codigoDaCausa.text() != '' || next.dtaInicio.text() != '' || next.nuOrdenacaoParaOItem.text() != '') {
                callDataAdd = "X";
            }
            break;
        }
    }
    message.setProperty("callDataAdd", callDataAdd);



    //*** Define tipo e valores p/ centro de trabalho e centro de planejamento de manutencao ***
    def tpCentroTrabalho = new String("V");
    it = xml.notifHeader.iterator();
    while (it.hasNext()) {
        
        def next = it.next();
        
        if (next.centroDeTrabalho.text().isNumber()) {
            tpCentroTrabalho = "N";
        } else if (next.centroDeTrabalho.text() != '') {
            tpCentroTrabalho = "A";
        } 
        message.setProperty("centroTrabalho", next.centroDeTrabalho.text());
        message.setProperty("centroPlanejamento", next.centroDePlanejamentoDeManutencao.text());

        break;
    } 
    message.setProperty("tpCentroTrabalho", tpCentroTrabalho);


   
    //*** Formata datas e horários ***
    def sdf = new SimpleDateFormat("yyyy-MM-dd");
    def sdfHora = new SimpleDateFormat("HH:mm:ss");
    
    if (xml.notifHeader.inicioDaAvariaData[0].text().length() == 8) {
        def dtInicio = Date.parse("yyyyMMdd", xml.notifHeader.inicioDaAvariaData[0].text())
        xml.notifHeader.inicioDaAvariaData[0].replaceNode { 
            inicioDaAvariaData(sdf.format(dtInicio)) {
            }
        }        
    }
    if (xml.notifHeader.fimDaAvariaData[0].text().length() == 8) {
        def dtFim = Date.parse("yyyyMMdd", xml.notifHeader.fimDaAvariaData[0].text())
        xml.notifHeader.fimDaAvariaData[0].replaceNode { 
            fimDaAvariaData(sdf.format(dtFim)) {
            }
        }        
    }
    if (xml.notifHeader.inicioDaAvariaHora[0].text().length() == 6 && xml.notifHeader.inicioDaAvariaHora[0].text().isNumber()) {
        def dtHoraIni = Date.parse("HHmmss", xml.notifHeader.inicioDaAvariaHora[0].text());
        xml.notifHeader.inicioDaAvariaHora[0].replaceNode { 
            inicioDaAvariaHora(sdfHora.format(dtHoraIni)) {
            }
        }  
    }    
    if (xml.notifHeader.fimDaAvariaHora[0].text().length() == 6 && xml.notifHeader.fimDaAvariaHora[0].text().isNumber()) {
        def dtHoraFim = Date.parse("HHmmss", xml.notifHeader.fimDaAvariaHora[0].text());
        xml.notifHeader.fimDaAvariaHora[0].replaceNode { 
            fimDaAvariaHora(sdfHora.format(dtHoraFim)) {
            }
        }  
    }  
    
    String outxml = groovy.xml.XmlUtil.serialize(xml);
    message.setBody(outxml);
    
    
   
    //*** Guarda payload request ***
    message.setProperty("requestPayload", outxml);    
    
    
    return message;
}