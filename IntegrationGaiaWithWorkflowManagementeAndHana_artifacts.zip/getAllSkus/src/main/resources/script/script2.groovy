import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    //Body
    def body = message.getBody(String);
    def jsonParser = new JsonSlurper()
    def mBody = jsonParser.parseText(body)

    def res = mBody.data.collect{it.sku}
    
    message.setBody(JsonOutput.toJson(res))
    
    
    return message;
}