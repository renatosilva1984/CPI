import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.util.XmlSlurper
import groovy.json.*;

def Map parseJson(String json){
    JsonSlurper slurper = new JsonSlurper()
    Map map = slurper.parseText(json)

    return map
}

def getJsonBodyAsMap(Message message) {
    String body = message.getBody(String)
    assert body

    def mBody = parseJson(body)

    return mBody
}

def String toJSON(Map map, Boolean pretty = true) {
    String json = JsonOutput.toJson(map)

    if (!pretty) return json

    String prettyJson = JsonOutput.prettyPrint(json)
    return prettyJson
}

def validateHierarchies(Map hierarchies) {
    assert hierarchies.primary
    assert hierarchies.primary.size() > 0
    assert hierarchies.secondaries != null

    ArrayList<String> validSecondaryHierarchyNames = [
        "marketing",
        "website",
        "site"
    ]
    
    
    if (hierarchies.secondaries.size() != 0) {
        for(key in hierarchies.secondaries.keySet()) {
            Boolean isValid = validSecondaryHierarchyNames.contains(key)
            if (!isValid) {
                String message = "$key is not one of the valid secondary hierarchies: [${validSecondaryHierarchyNames.join(", ")}]"
                throw new Exception(message)
            }
        }
    }
}

def Message processData(Message message) {

    Map body = getJsonBodyAsMap(message)
    Map hierarchies = body.hierarchies
    
    if (!hierarchies) throw new Exception("Missing hierarchies key in body.")
    
    validateHierarchies(hierarchies)

    String hierarchiesJson = toJSON(hierarchies, false)
    message.setProperty("hierarchies", hierarchiesJson)
    
    return message;
}