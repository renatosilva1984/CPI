/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.QName;

def Message processData(Message message) {
    
    def body = message.getBody(String)
    def xml = new XmlParser().parseText(body);
    def it = xml.Notifheader.iterator();

    //Novo nó a ser adicionado no XML original
    def newNode = new Node(null, 'NotifheaderX', null)

    while (it.hasNext()) {
      
        def next = it.next();

        if (next.Equipment.text() != '') {
            new Node(newNode,'Equipment', null, 'X')
        }
        if (next.ShortText.text() != '') {
            new Node(newNode,'ShortText', null, 'X')
        }
        if (next.PmWkctr.text() != '') {
            new Node(newNode,'PmWkctr', null, 'X')
        }
        if (next.Planplant.text() != '') {
            new Node(newNode,'Planplant', null, 'X')
        }
        if (next.Plangroup.text() != '') {
            new Node(newNode,'Plangroup', null, 'X')
        }
        if (next.Strmlfndate.text() != '') {
            new Node(newNode,'Strmlfndate', null, 'X')
        }
        if (next.Strmlfntime.text() != '') {
            new Node(newNode,'Strmlfntime', null, 'X')
        }
        if (next.Reportedby.text() != '') {
            new Node(newNode,'Reportedby', null, 'X')
        }
        if (next.Endmlfndate.text() != '') {
            new Node(newNode,'Endmlfndate', null, 'X')
        }
        if (next.Endmlfntime.text() != '') {
            new Node(newNode,'Endmlfntime', null, 'X')
        }
        if (next.xx.text() != '') {
            new Node(newNode,'xx', null, 'X')
        }
    }
    
    def xmlOut = new XmlParser().parseText(body);
    xmlOut.append(newNode)
    String outxml = groovy.xml.XmlUtil.serialize( xmlOut )
    message.setBody(outxml)

    return message;
    
}