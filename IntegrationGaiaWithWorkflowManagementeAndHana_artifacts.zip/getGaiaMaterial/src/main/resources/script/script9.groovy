import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    def body    = message.getBody(String)
    def slurper = new JsonSlurper()
    def jsonObj = slurper.parseText(body)
    
    // Converte o RESIZE em String
    jsonObj.assets.images.each{ e ->
        if( e.resize != null){
            e.resize = new JsonBuilder(e.resize).toString()
        }
    }
    jsonObj.assets.documents.each{ e ->
        if( e.resize != null){
            e.resize = new JsonBuilder(e.resize).toString()
        }
    }

    def json = JsonOutput.toJson(
        sku:         jsonObj.sku,
        name:        jsonObj.name,
        context:     jsonObj.context,
        brand:       jsonObj.brand,
        subBrand:    jsonObj.subBrand,
        hierarchies: jsonObj.hierarchies,
        assets:      jsonObj.assets,
        attributes:  jsonObj.attributes
    )

    message.setBody(JsonOutput.prettyPrint(json))

    return message;
}

