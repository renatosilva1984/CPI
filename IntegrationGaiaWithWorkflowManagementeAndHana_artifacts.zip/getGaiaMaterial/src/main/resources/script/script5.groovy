import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    Map properties = message.getProperties()

    String sku = properties.sku

    assert sku

    return message
}