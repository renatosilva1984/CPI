import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def String toPrettyJson(input) {
    def json = JsonOutput.toJson(input)
    return JsonOutput.prettyPrint(json)
}

def Message processData(Message message) {
    String body = message.getBody(String)
    assert body

    def jsonSlurper = new JsonSlurper()
    def mBody = jsonSlurper.parseText(body)

    mBody.attributes = mBody.attributes.findAll{it.format != "binary"}

    def payload = toPrettyJson(mBody)
    
    message.setBody(payload)
    return message;
}