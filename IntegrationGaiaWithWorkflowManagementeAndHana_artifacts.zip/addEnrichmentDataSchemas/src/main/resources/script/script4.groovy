import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*

def Message processData(Message message) {
    Map properties = message.getProperties()

    String sku = properties.sku
    String hierarchy = properties.hierarchy

    assert hierarchy
    assert sku

    return message
}