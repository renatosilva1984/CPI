
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.regex.Pattern
def Message processData(Message message) {
    //Body
    String body = message.getBody(String);
    Pattern emptyTag = ~"<[a-zA-Z]+/>|<[a-zA-Z]+></[a-zA-Z]+>"
    String newBody = body.replaceAll(emptyTag, "")
    
    message.setBody(newBody)
    
    return message;
}