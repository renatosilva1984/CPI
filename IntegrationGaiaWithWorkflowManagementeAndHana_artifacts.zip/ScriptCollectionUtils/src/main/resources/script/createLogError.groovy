import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*
    
def Message processData(Message message) {
    def builder     = new JsonBuilder()
    def date        = new Date()
    def createdDate = date.format("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", TimeZone.getTimeZone("GMT-3"));
    def statusCode  = message.getHeaders().get("CamelHttpResponseCode")
    
    def log = builder{
        "sku" message.getProperties().get("sku")
        "description" message.getBody(String)
        
        if(statusCode != 200){
            "code" statusCode
        }else{
            "code" 500
        }
        
        "artifact" message.getProperties().get("p_iflow_name")
        "created_at" createdDate
    }
    
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(log)))
    message.setHeader("sku", message.getProperties().get("sku"))
    
    return message;
}