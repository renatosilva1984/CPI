importClass(com.sap.gateway.ip.core.customdev.util.Message);
importClass(java.util.HashMap);
function processData(message) {
    
    var guidCreate = function () {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    var bodyGrayLog = JSON.parse("{}");
    
    //Origin
    var origin = String(message.getProperty("origin"));
    
    //Requesting
    var req = String(message.getProperty("requesting"));

    //FlowName
    var flow = String(message.getProperty("nameFlow"));
    
    //Payload
    var before = String(message.getProperty("payload"));
    
    //Response
    var after = String(message.getBody());
    message.setProperty("ResponseBody", after);
    
    bodyGrayLog.application ="CPI";
    bodyGrayLog.transactionId = guidCreate();
    bodyGrayLog.transactionName = flow;
    bodyGrayLog.type = "ERROR";
    bodyGrayLog.originApplication = origin;
    bodyGrayLog.requestingApplication = req;
    bodyGrayLog.Payload = JSON.parse("{}");
    bodyGrayLog.Payload.before = before;
    bodyGrayLog.Payload.after = "Error na entrega para S4HANA - MDG.";

    message.setBody(JSON.stringify(bodyGrayLog));

    return message;
}